import pandas as pd

file_path = "/content/drive/MyDrive/CIENCIA DE DATOS 2025 -2 /reto/reto grupo serrano.xlsx"

# Read the Excel file, skipping the first 3 rows to start from E4 (index 3)
df = pd.read_excel(file_path, skiprows=3, header=0)

# Select data starting from the column corresponding to E (index 4) and onwards
df_selected = df.iloc[:, 4:]

# Transpose the DataFrame
df_transposed = df_selected.T

# Select the first 3 columns
df_final = df_transposed.iloc[:, :3]

# Reset the index and rename the columns
df_final = df_final.reset_index()
df_final.columns = ['trimestre', 'total trimestre', 'animales', 'unnamed']

# Drop the unnamed column
df_final = df_final.drop(columns=['unnamed'])

# Display the first few rows of the final DataFrame
display(df_final.head())
# Clean 'animales' column by converting to numeric and replacing errors with 0
df_final['animales'] = pd.to_numeric(df_final['animales'], errors='coerce').fillna(0)

# Extract year from 'trimestre'
df_final['year'] = df_final['trimestre'].str.extract(r'(\d{4})')

# Group by year and sum 'animales' to create a new DataFrame with yearly totals
df_yearly_total = df_final.groupby('year')['animales'].sum().reset_index()

# Rename columns for clarity
df_yearly_total.columns = ['año', 'total anual']

# Display the result (the yearly totals)
display(df_yearly_total)

# The original df_final DataFrame remains unchanged with the cleaning applied
# display(df_final.head()) # Uncomment to display the modified df_final
from google.colab import files

# Export the df_yearly_total DataFrame to an Excel file
excel_output_path = "/content/yearly_animal_totals.xlsx"
df_yearly_total.to_excel(excel_output_path, index=False)

print(f"Yearly totals exported to {excel_output_path}")

# Download the file
files.download(excel_output_path)
import plotly.express as px

# Create a dynamic line plot of yearly totals
fig = px.line(df_yearly_total, x='año', y='total anual', title='Total Anual de Animales por Año')

# Display the plot
fig.show()